type Streamlabs = {
    [s: string]: any,
}

export default Streamlabs;