type Auth = {
    token: string,
    userId: string,
    channelId: string,
    clientId: string,
}

export default Auth;