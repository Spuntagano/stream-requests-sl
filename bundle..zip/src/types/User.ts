type User = {
    displayName: string,
    userId: string
}

export default User;