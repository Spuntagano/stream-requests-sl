type Configs = {
    purchaseURL: string,
    relayURL: string,
    wsURL: string,
    ipnURL: string,
    returnURL: string,
    cdnBasePath: string
}

export default Configs;