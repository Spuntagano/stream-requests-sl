type Request = {
    [s: string]: any,
}

export default Request;