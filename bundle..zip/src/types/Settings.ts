type Settings = {
    [s: string]: any,
}

export default Settings;